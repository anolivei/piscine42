void	ft_putnbr_base(int nbr, char *base);

int main()
{
	ft_putnbr_base(10, "01");

}

