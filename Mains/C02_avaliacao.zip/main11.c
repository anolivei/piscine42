/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main11.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anolivei <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/02 16:47:48 by anolivei          #+#    #+#             */
/*   Updated: 2019/12/02 21:17:43 by anolivei         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

void ft_putstr_non_printable(char *str);

int	main(void)
{
	char *str;
	char texto[] = "Vida\nlonga\be prospera\a";

	str = texto;
	ft_putstr_non_printable(str);
}
