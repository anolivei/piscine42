/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main1.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anolivei <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/04 13:58:48 by anolivei          #+#    #+#             */
/*   Updated: 2019/12/05 04:36:58 by anolivei         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

int ft_strncmp(char *s1, char *s2, unsigned int n);

int	main(void)
{
	char str1[] = "And I'm shaking like a leaf";
	char str2[] = "And they call me underneath";
	int n;
	
	n = 6;	
	printf("Funcao criada: %d\n", ft_strncmp(str1, str2, n));
	printf("Funcao original: %d\n", strncmp(str1, str2, n));
	return (0);
}
