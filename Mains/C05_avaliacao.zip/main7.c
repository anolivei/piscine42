/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gmarsi <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/04 23:45:20 by gmarsi            #+#    #+#             */
/*   Updated: 2019/12/05 09:09:10 by gmarsi           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

int ft_find_next_prime(int nb);

int main(void)
{
	int i;
	int n;

	n = 12345;
	i = ft_find_next_prime(n);
	printf("\nO proximo primo de	%d	eh	%d\n", n, i);
}
