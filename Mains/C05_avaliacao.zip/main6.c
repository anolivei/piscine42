/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gmarsi <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/04 21:18:43 by gmarsi            #+#    #+#             */
/*   Updated: 2019/12/04 23:39:20 by gmarsi           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

int ft_is_prime(int nb);

int main(void)
{
	int numero;
	int resultado;

	numero = 0;
	resultado = ft_is_prime(numero);
	resultado == 1 ? printf("\nO algoritimo calculou que %d eh um numero primo\n", numero) :
				 printf("\nO algoritimo calculou que %d NAO eh um numero primo\n", numero);
	numero = 1;
	resultado = ft_is_prime(numero);
	resultado == 1 ? printf("O algoritimo calculou que %d eh um numero primo\n", numero) :
				 printf("O algoritimo calculou que %d NAO eh um numero primo\n", numero);

	numero = 2;
	resultado = ft_is_prime(numero);
	resultado == 1 ? printf("O algoritimo calculou que %d eh um numero primo\n", numero) :
				 printf("O algoritimo calculou que %d NAO eh um numero primo\n", numero);

	numero = 3;
	resultado = ft_is_prime(numero);
	resultado == 1 ? printf("O algoritimo calculou que %d eh um numero primo\n", numero) :
				 printf("O  algoritimo calculou que %d NAO eh um numero primo\n", numero);

	numero = 4;
	resultado = ft_is_prime(numero);
	resultado == 1 ? printf("O algoritimo calculou que %d eh um numero primo\n", numero) :
				 printf("O algoritimo calculou que %d NAO eh um numero primo\n", numero);

	numero = 5;
	resultado = ft_is_prime(numero);
	resultado == 1 ? printf("O algoritimo calculou que %d eh um numero primo\n", numero) :
				 printf("O algoritimo calculou que %d NAO eh um numero primo\n", numero);

	numero = 11;
	resultado = ft_is_prime(numero);
	resultado == 1 ? printf("O algoritimo calculou que %d eh um numero primo\n", numero) :
				 printf("O algoritimo calculou que %d NAO eh um numero primo\n", numero);

	numero = 13;
	resultado = ft_is_prime(numero);
	resultado == 1 ? printf("O algoritimo calculou que %d eh um numero primo\n", numero) :
				 printf("O algoritimo calculou que %d NAO eh um numero primo\n", numero);

	numero = 15;
	resultado = ft_is_prime(numero);
	resultado == 1 ? printf("O algoritimo calculou que %d eh um numero primo\n", numero) :
				 printf("O algoritimo calculou que %d NAO eh um numero primo\n", numero);

	numero = 97;
	resultado = ft_is_prime(numero);
	resultado == 1 ? printf("O algoritimo calculou que %d eh um numero primo\n", numero) :
				 printf("O algoritimo calculou que %d NAO eh um numero primo\n", numero);

	numero = 524287;
	resultado = ft_is_prime(numero);
	resultado == 1 ? printf("O algoritimo calculou que %d eh um numero primo\n", numero) :
				 printf("O algoritimo calculou que %d NAO eh um numero primo\n", numero);

	numero = 2147483647;
	resultado = ft_is_prime(numero);
	resultado == 1 ? printf("O algoritimo calculou que %d eh um numero primo\n\n", numero) :
				 printf("O algoritimo calculou que %d NAO eh um numero primo\n\n", numero);
}
