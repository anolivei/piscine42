/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gmarsi <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/04 08:17:58 by gmarsi            #+#    #+#             */
/*   Updated: 2019/12/04 08:55:55 by gmarsi           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

int ft_iterative_factorial(int nb);

int main(void)
{
	int res;
	int valor;
	
	valor = -1;
	res  = ft_iterative_factorial(valor);
	printf("\nResultado esperado de %d!  : 0          O valor  calculado foi:  %d\n", valor, res);
	
	valor = 0;
	res  = ft_iterative_factorial(valor);
	printf("Resultado esperado de %d!   : 1          O valor  calculado foi:  %d\n", valor, res);
	
	valor = 1;
	res  = ft_iterative_factorial(valor);
	printf("Resultado esperado de %d!   : 1          O valor  calculado foi:  %d\n", valor, res);
	
	valor = 2;
	res  = ft_iterative_factorial(valor);
	printf("Resultado esperado de %d!   : 2          O valor  calculado foi:  %d\n", valor, res);
	
	valor = 3;
	res  = ft_iterative_factorial(valor);
	printf("Resultado esperado de %d!   : 6          O valor  calculado foi:  %d\n", valor, res);
	
	valor = 4;
	res  = ft_iterative_factorial(valor);
	printf("Resultado esperado de %d!   : 24         O valor  calculado foi:  %d\n", valor, res);
	
	valor = 5;
	res  = ft_iterative_factorial(valor);
	printf("Resultado esperado de %d!   : 120        O valor  calculado foi:  %d\n", valor, res);
	
	valor = 10;
	res  = ft_iterative_factorial(valor);
	printf("Resultado esperado de %d!  : 3628800    O valor  calculado foi:  %d\n", valor, res);
	
	valor = 11;
	res  = ft_iterative_factorial(valor);
	printf("Resultado esperado de %d!  : 39916800   O valor  calculado foi:  %d\n", valor, res);
	
	valor = 12;
	res  = ft_iterative_factorial(valor);
	printf("Resultado esperado de %d!  : 479001600  O valor  calculado foi:  %d\n", valor, res);
	
	valor = 13;
	res  = ft_iterative_factorial(valor);
	printf("Resultado esperado de %d!  : 0          O valor  calculado foi:  %d\n\n", valor, res);
}
