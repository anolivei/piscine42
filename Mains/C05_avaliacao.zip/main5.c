/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gmarsi <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/04 20:14:33 by gmarsi            #+#    #+#             */
/*   Updated: 2019/12/05 00:13:40 by gmarsi           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

int ft_sqrt(int nb);

int main(void)
{
	int i;
	int valor;

	i = -5;
	valor = ft_sqrt(i);
	printf("\nA raiz quadrada de	%d	eh:	%d\n", i, valor);

	i = 0;
	valor = ft_sqrt(i);
	printf("A raiz quadrada de	%d	eh:	%d\n", i, valor);

	i = 1;
	valor = ft_sqrt(i);
	printf("A raiz quadrada de	%d	eh:	%d\n", i, valor);

	i = 2;
	valor = ft_sqrt(i);
	printf("A raiz quadrada de	%d	eh:	%d\n", i, valor);

	i = 4;
	valor = ft_sqrt(i);
	printf("A raiz quadrada de	%d	eh:	%d\n", i, valor);

	i = 81;
	valor = ft_sqrt(i);
	printf("A raiz quadrada de	%d	eh:	%d\n", i, valor);

	i = 1764;
	valor = ft_sqrt(i);
	printf("A raiz quadrada de	%d	eh:	%d\n", i, valor);

	i = 2147483647;
	valor = ft_sqrt(i);
	printf("A raiz quadrada de %d	eh:	%d\n\n", i, valor);
}
