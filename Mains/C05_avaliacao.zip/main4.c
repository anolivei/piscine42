/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gmarsi <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/04 17:02:31 by gmarsi            #+#    #+#             */
/*   Updated: 2019/12/04 19:17:36 by gmarsi           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

int ft_fibonacci(int index);

int main(void)
{
	int i;
	int resultado;

	i = -5;
	resultado = ft_fibonacci(i);
	printf("\nO valor esperado para o index -5 eh:	-1		-		O valor encontrado foi:	%d", resultado);

	i = 0;
	resultado = ft_fibonacci(i);
	printf("\nO valor esperado para o index  0 eh:	0		-		O valor encontrado foi:	%d", resultado);

	i = 1;
	resultado = ft_fibonacci(i);
	printf("\nO valor esperado para o index  1 eh:	1		-		O valor encontrado foi:	%d", resultado);

	i = 5;
	resultado = ft_fibonacci(i);
	printf("\nO valor esperado para o index  5 eh:	5		-		O valor encontrado foi:	%d", resultado);

	i = 10;
	resultado = ft_fibonacci(i);
	printf("\nO valor esperado para o index 10 eh:	55		-		O valor encontrado foi:	%d", resultado);

	i = 15;
	resultado = ft_fibonacci(i);
	printf("\nO valor esperado para o index 15 eh:	610		-		O valor encontrado foi:	%d", resultado);

	i = 20;
	resultado = ft_fibonacci(i);
	printf("\nO valor esperado para o index 20 eh:	6765		-		O valor encontrado foi:	%d", resultado);

	i = 40;
	resultado = ft_fibonacci(i);
	printf("\nO valor esperado para o index 40 eh:	102334155	-		O valor encontrado foi:	%d\n\n", resultado);
}
