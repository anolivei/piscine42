/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gmarsi <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/04 12:12:53 by gmarsi            #+#    #+#             */
/*   Updated: 2019/12/04 13:57:09 by gmarsi           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

int ft_recursive_power(int nb, int power);

int main(void)
{
	int pot;
	int num;
	int retorno;

	pot = 0;
	num = 0;
	retorno = ft_recursive_power(num, pot);
	printf("\n%d	elevado a	%d	resulta no valor: %d\n", num, pot, retorno);

	pot = 0;
	num = 123456;
	retorno = ft_recursive_power(num, pot);
	printf("%d	elevado a	%d	resulta no valor: %d\n", num, pot, retorno);

	pot = -2;
	num = 5;
	retorno = ft_recursive_power(num, pot);
	printf("%d	elevado a	%d	resulta no valor: %d\n", num, pot, retorno);

	pot = 3;
	num = 0;
	retorno = ft_recursive_power(num, pot);
	printf("%d	elevado a	%d	resulta no valor: %d\n", num, pot, retorno);

	pot = 3;
	num = -10;
	retorno = ft_recursive_power(num, pot);
	printf("%d	elevado a	%d	resulta no valor: %d\n", num, pot, retorno);

	pot = 4;
	num = -10;
	retorno = ft_recursive_power(num, pot);
	printf("%d	elevado a	%d	resulta no valor: %d\n", num, pot, retorno);

	pot = 3;
	num = 2;
	retorno = ft_recursive_power(num, pot);
	printf("%d	elevado a	%d	resulta no valor: %d\n", num, pot, retorno);

	pot = 8;
	num = 12;
	retorno = ft_recursive_power(num, pot);
	printf("%d	elevado a	%d	resulta no valor: %d\n", num, pot, retorno);

	pot = 15;
	num = 23;
	retorno = ft_recursive_power(num, pot);
	printf("%d	elevado a	%d	resulta no valor: %d\n\n", num, pot, retorno);
}
